/**
 * 
 */
package com.kdc;


import java.util.Map;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

/**
 * @author ripit
 *
 */
@RestController
public class HomeController {

	@RequestMapping(value = "/process",method = RequestMethod.POST,consumes = "text/plain")
	public String getElements(@RequestBody String json) throws JsonMappingException, JsonProcessingException, UnirestException {
		
		System.out.println(json);		
		
		JsonObject jobj = new Gson().fromJson(json, JsonObject.class);

		String event = jobj.get("ev").getAsString();
		String event_type = jobj.get("et").getAsString();
		String app_id = jobj.get("id").getAsString();
		String user_id = jobj.get("uid").getAsString();
		String message_id = jobj.get("mid").getAsString();
		String page_title = jobj.get("t").getAsString();
		String page_url = jobj.get("p").getAsString();
		String browser_language = jobj.get("l").getAsString();
		String screen_size = jobj.get("sc").getAsString();
		
		JSONObject jsonobj =  new JSONObject();
		jsonobj.put("event", event);
		jsonobj.put("event_type", event_type);
		jsonobj.put("app_id", app_id);
		jsonobj.put("user_id", user_id);
		jsonobj.put("message_id", message_id);
		jsonobj.put("page_title", page_title);
		jsonobj.put("page_url", page_url);
		jsonobj.put("browser_language", browser_language);
		jsonobj.put("screen_size", screen_size);		
		
		
		JSONObject jsonobj2 =  new JSONObject();
		Boolean attributeAvailable = false;
		int indexCount = 1;
		do {
			attributeAvailable = false;
			String atrk = "";
			String atrv = "";
			String atrt = "";
			if (jobj.get("atrk" + indexCount) != null) {
				attributeAvailable = true;
				atrk = jobj.get("atrk" + indexCount).getAsString();
	        } 
			if (jobj.get("atrv" + indexCount) != null) {
				attributeAvailable = true;
				atrv = jobj.get("atrv" + indexCount).getAsString();
	        } 
			if (jobj.get("atrt" + indexCount) != null) {
				attributeAvailable = true;
				atrt = jobj.get("atrt" + indexCount).getAsString();
	        }
        	JSONObject jsonobj1 =  new JSONObject();
        	if(attributeAvailable) {
        		jsonobj1.put("type", atrt);
            	jsonobj1.put("value", atrv);        	
            	jsonobj2.put(atrk, jsonobj1);
        	}
        	indexCount++;
        	
        }while(attributeAvailable);
		
		JSONObject jsonobj3 =  new JSONObject();
		attributeAvailable = false;
		indexCount  =1;
		do {
			attributeAvailable = false;
			String uatrk = "";
			String uatrv = "";
			String uatrt = "";
			if (jobj.get("uatrk" + indexCount) != null) {
				attributeAvailable = true;
				uatrk = jobj.get("uatrk" + indexCount).getAsString();
	        }
			if (jobj.get("uatrv" + indexCount) != null) {
				attributeAvailable = true;
				uatrv = jobj.get("uatrv" + indexCount).getAsString();
	        }
			if (jobj.get("uatrt" + indexCount) != null) {
				attributeAvailable = true;
				uatrt = jobj.get("uatrt" + indexCount).getAsString();
	        }
				
        	JSONObject jsonobj1 =  new JSONObject();
        	if(attributeAvailable) {
        		jsonobj1.put("type", uatrt);
            	jsonobj1.put("value", uatrv);        	
            	jsonobj3.put(uatrk, jsonobj1);
            	
        	}
        	indexCount++;
        	
        }while(attributeAvailable);
		
		jsonobj.put("attributes", jsonobj2);
		jsonobj.put("traits", jsonobj3);		
		
		System.out.println(jsonobj);
		
		docall(jsonobj.toString());	
		return jsonobj.toString();
	}
	
	private void docall(String body) throws UnirestException {
		HttpResponse<String> response = Unirest.post("https://webhook.site/")
				  .header("content-type", "application/json")
				  .header("cache-control", "no-cache")
				  .header("postman-token", "7cf6d356-9128-afe8-7c6b-ff55eed05061")
				  .body(body)
				  .asString();
		
		System.out.println(response.getStatus());
		System.out.println(response.getBody());
	}
	
}
