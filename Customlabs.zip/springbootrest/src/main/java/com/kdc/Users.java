/**
 * 
 */
package com.kdc;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * @author ripit
 *
 */
public class Users {
	
	private String ev;
	private String et;
	private String id;
	private String uid;
	private String mid;
	private String t;
	private String p;
	private String l;
	private String sc;	
	
	private Map<String, Object> atrk;
	private Map<String, Object> atrv;
	private Map<String, Object> atrt;
	
	 
	//private List<Userattributes> attributes;
	//private List<Usertraits> traits;
	
	public String getEv() {
		return ev;
	}
	public void setEv(String ev) {
		this.ev = ev;
	}
	public String getEt() {
		return et;
	}
	public void setEt(String et) {
		this.et = et;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getT() {
		return t;
	}
	public void setT(String t) {
		this.t = t;
	}
	public String getP() {
		return p;
	}
	public void setP(String p) {
		this.p = p;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	public String getSc() {
		return sc;
	}
	public void setSc(String sc) {
		this.sc = sc;
	}
	/*
	 * public List<Userattributes> getAttributes() { return attributes; } public
	 * void setAttributes(List<Userattributes> attributes) { this.attributes =
	 * attributes; } public List<Usertraits> getTraits() { return traits; } public
	 * void setTraits(List<Usertraits> traits) { this.traits = traits; }
	 */
	public Map<String, Object> getAtrk() {
		return atrk;
	}
	public void setAtrk(Map<String, Object> atrk) {
		this.atrk = atrk;
	}
	public Map<String, Object> getAtrv() {
		return atrv;
	}
	public void setAtrv(Map<String, Object> atrv) {
		this.atrv = atrv;
	}
	public Map<String, Object> getAtrt() {
		return atrt;
	}
	public void setAtrt(Map<String, Object> atrt) {
		this.atrt = atrt;
	}
	
	
	
	
	
	
	
	

}
