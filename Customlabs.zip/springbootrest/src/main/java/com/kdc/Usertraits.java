/**
 * 
 */
package com.kdc;

/**
 * @author ripit
 *
 */
public class Usertraits {

	private String uatrk;
	private String uatrv;
	private int uatrt;
	
	public String getUatrk() {
		return uatrk;
	}
	public void setUatrk(String uatrk) {
		this.uatrk = uatrk;
	}
	public String getUatrv() {
		return uatrv;
	}
	public void setUatrv(String uatrv) {
		this.uatrv = uatrv;
	}
	public int getUatrt() {
		return uatrt;
	}
	public void setUatrt(int uatrt) {
		this.uatrt = uatrt;
	}
	
	
}
