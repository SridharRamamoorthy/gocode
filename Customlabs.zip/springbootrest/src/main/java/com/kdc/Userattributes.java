/**
 * 
 */
package com.kdc;

/**
 * @author ripit
 *
 */
public class Userattributes {
	
	private String atrk;
	private String atrv;
	private String atrt;
	
	public String getAtrk() {
		return atrk;
	}
	public void setAtrk(String atrk) {
		this.atrk = atrk;
	}
	public String getAtrv() {
		return atrv;
	}
	public void setAtrv(String atrv) {
		this.atrv = atrv;
	}
	public String getAtrt() {
		return atrt;
	}
	public void setAtrt(String atrt) {
		this.atrt = atrt;
	}
	
	


}
